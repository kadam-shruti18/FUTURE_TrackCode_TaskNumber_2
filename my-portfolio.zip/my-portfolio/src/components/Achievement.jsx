import React from 'react';

const Achievement = () => {
  return (
    <div>
      <h3 className="section-title">ACHIEVEMENTS</h3>
      <ul className="ul-update">
        <li>JLPT N4 Certification</li>
        <li>Full Stack Web Development Certificate</li>
      </ul>
    </div>
  );
};

export default Achievement;
