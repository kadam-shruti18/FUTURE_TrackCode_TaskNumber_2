import React from 'react';

const Profile = () => {
  return (
    <div>
      <h3 className="section-title">PROFILE</h3>
      <p>
        Motivated and detail-oriented Full Stack Web Developer with strong expertise
        in HTML, CSS, JavaScript, React, Python, and Django. Builds responsive and interactive apps.
      </p>
    </div>
  );
};

export default Profile;
