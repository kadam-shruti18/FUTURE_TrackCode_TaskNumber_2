import React from 'react';

const Education = () => {
  return (
    <div>
      <h3 className="section-title">EDUCATION</h3>
      <p>Bachelor of Commerce – Completed July 2024</p>
      <p>HSC, Maharashtra State Board – Passed 2021</p>
      <p>SSC, Maharashtra State Board – Passed 2019</p>
    </div>
  );
};

export default Education;
