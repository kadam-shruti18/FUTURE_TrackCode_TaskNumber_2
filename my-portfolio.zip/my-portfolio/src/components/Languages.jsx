import React from 'react';

const Languages = () => {
  return (
    <div>
      <h3 className="section-title">LANGUAGES</h3>
      <ul className="ul-update">
        <li>English</li>
        <li>Hindi</li>
        <li>Marathi</li>
        <li>Japanese</li>
      </ul>
    </div>
  );
};

export default Languages;
