import React from 'react';

const Skills = () => {
  return (
    <div>
      <h3 className="section-title">SKILLS</h3>
      <ul className="ul-update">
        <li>JavaScript</li>
        <li>React</li>
        <li>Python</li>
        <li>Django</li>
      </ul>
    </div>
  );
};

export default Skills;
