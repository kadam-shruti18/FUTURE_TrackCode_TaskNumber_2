import React from 'react';
function Header(){
 return(
    <header>
    <div id="name">GAYATRI RODAGE</div>
    <div id="education">Full Stack Web Developer</div>
    <div className="top-line"></div>
    <div className="top-line2"></div>
    <div id="address">
      <ul>
        <li>New Mumbai</li>
        <li>91-9284968200</li>
        <li>rodagegayu12@gmail.com</li>
      </ul> 
    </div> 
    </header>
);
}
export default Header;
