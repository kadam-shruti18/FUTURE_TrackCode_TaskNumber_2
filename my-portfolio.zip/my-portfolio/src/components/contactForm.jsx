import React, { useState } from "react";
import emailjs from "@emailjs/browser";
import "./ContactForm.css"; // Optional CSS

const ContactForm = () => {
  const [formData, setFormData] = useState({
    
    
    name:"Shruti rodage",
    email: "",
    phone: "",
    recipientName: "",
    message: "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const sendEmail = (e) => {
    e.preventDefault();

    emailjs
      .send("service_9l2vd0d", "template_cxpz57j", formData, "OEnku8Rd_v568VYV0")
      .then(
        () => {
          alert("Email sent successfully!");
          setFormData({ name: "", email: "", phone: "", recipientName: "", message: "" });
        },
        (error) => {
          console.error("Email failed:", error);
          alert("Failed to send message.");
        }
      );
  };

  return (
    <div className="contact-container">
      <form id="contactForm" onSubmit={sendEmail}>
        <h2>Get in touch</h2>
        <hr className="d1" />
        
       <input type="text" id="name" name="name" className="form-input" placeholder="Shruti Rodage" value={formData.name} onChange={handleChange} required />
        <input type="email" id="email" name="email" className="form-input" placeholder="Email address" value={formData.email} onChange={handleChange} required /><br />
        <input type="text" id="phone" name="phone" className="form-input" placeholder="Contact number" value={formData.phone} onChange={handleChange} required /> 
        <input type="text" name="recipientName" className="form-input" placeholder="Receiver's name" value={formData.recipientName} onChange={handleChange} required /><br />
        <textarea id="message" name="message" className="form-input" placeholder="Message" value={formData.message} onChange={handleChange} required></textarea><br />

        <button  id="submit" type="submit">Submit</button>
      </form>
    </div>
  );

};

export default ContactForm;
