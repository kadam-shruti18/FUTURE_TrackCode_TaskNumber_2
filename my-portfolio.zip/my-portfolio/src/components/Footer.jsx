import React from 'react';


const Footer = () => {
  return (
    <footer style={{ textAlign: 'center', marginTop: '40px', fontSize: '1rem', color: '#555' }}>
      Gayatri Rodage © 2025 | Thanks for visiting!
    </footer>
  );
};


 export default Footer;
