import React from 'react';

const Projects = () => {
  return (
    <div>
      <h3 className="section-title">PROJECTS</h3>
      <ul className="ul-update">
        <li>BMI Calculator – Developed using HTML5, CSS3, and JavaScript with mobile responsiveness.</li>
        <li>Unit Counters – Created an interactive counter with real-time JavaScript updates.</li>
        <li>Employees.com – Django-based employee management system with CRUD features.</li>
        <li>Mysirg Classes – Educational website layout inspired by Mysirg.com using HTML, CSS, JS.</li>
      </ul>
    </div>
  );
};

export default Projects;

