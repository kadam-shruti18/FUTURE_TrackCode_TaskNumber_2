import React, { useState } from 'react';
import Profile from './Profile';
import Skills from './Skills';
import Projects from './Projects';
import Achievement from './Achievement';

const Tabs = () => {
  const [activeTab, setActiveTab] = useState('profile');

  const tabList = ['profile', 'skills', 'projects', 'achievement'];

  const renderContent = () => {
    switch (activeTab) {
      case 'profile':
        return <Profile />;
      case 'skills':
        return <Skills />;
      case 'projects':
        return <Projects />;
      case 'achievement':
        return <Achievement />;
      default:
        return null;
    }
  };

  return (
    <div>
      <div className="tabs">
        {tabList.map((tab) => (
          <button
            key={tab}
            className={`tab-button ${activeTab === tab ? 'active' : ''}`}
            onClick={() => setActiveTab(tab)}
          >
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      <div className="tab-content">{renderContent()}</div>
    </div>
  );
};

export default Tabs;
