import React, { useState } from 'react';
import Header from "./components/Header";
import Languages from "./components/Languages"; 
import Education from "./components/Education";
import Footer from "./components/Footer";
import Tabs from "./components/Tabs";
import ContactForm from "./components/ContactForm";
import './App.css';

function App() {
  const [showContactForm, setShowContactForm] = useState(false);

  const toggleContactForm = () => {
    setShowContactForm(prev => !prev);
  };

  return (
    <>
      <div className="portfolio">
        <Header />
        <Tabs />
        <Languages />
        <Education />
         </div>
         <Footer />
        <div className="contact-button-section" style={{ textAlign: 'center', margin: '30px 0'}}>
          <button className="contact-button" onClick={toggleContactForm}>
            📞 Contact Me
          </button>
        </div>

      
        {showContactForm && (
          <div className="contact-form-container">
            <ContactForm />
          </div>
        )}
      

      
    </>
  );
}

export default App;
